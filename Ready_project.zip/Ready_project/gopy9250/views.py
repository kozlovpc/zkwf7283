from django.shortcuts import render, redirect
from .models import FormData

def dynamic_form(request):
    if request.method == 'POST':
        # Очистка базы перед сохранением новых данных
        FormData.objects.all().delete()
        
        latitudes = request.POST.getlist('lat')
        longitudes = request.POST.getlist('lng')
        
        for lat, lng in zip(latitudes, longitudes):
            lat_val = float(lat) if lat.strip() else 0.0
            lng_val = float(lng) if lng.strip() else 0.0
            
            FormData.objects.create(
                latitude=lat_val,
                longitude=lng_val
            )
            
        return redirect('success')
    
    return render(request, 'form.html')

def success_view(request):
    data = FormData.objects.all().order_by('-created_at')
    return render(request, 'success.html', {'data': data})