from django.shortcuts import render, redirect
from .models import FormData


def dynamic_form(request):
    if request.method == 'POST':
        fields = request.POST.getlist('fields')
        for value in fields:
            if value.strip():
                FormData.objects.create(content=value.strip())

        return redirect('success_url')

    return render(request, 'form.html')


def success_view(request):
    # Получаем все сохраненные данные из PostgreSQL
    data = FormData.objects.all().order_by('-created_at')
    return render(request, 'success.html', {'data': data})
