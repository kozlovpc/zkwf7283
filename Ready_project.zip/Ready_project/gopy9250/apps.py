from django.apps import AppConfig


class Gopy9250Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gopy9250'
