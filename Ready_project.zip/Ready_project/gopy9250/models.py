from django.db import models

class FormData(models.Model):
    content = models.CharField(max_length=255)  # Поле для хранения данных из input
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.content