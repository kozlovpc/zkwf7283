from django.contrib import admin
from django.urls import path
from gopy9250.views import dynamic_form

urlpatterns = [
    path('', dynamic_form, name='form'),
    ]